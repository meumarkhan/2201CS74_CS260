function nextpage(){
    window.location.href = ("http://127.0.0.1:5500/page3.html")
}